 var app = angular.module("myApp",[]);

app.run(function($rootScope) {
    $rootScope.personsArray = []; 
});

app.service('myService', function() {
    this.validate = function(fname,lname,mob){
	if(fname == "" || fname == null){
		alert("Fname is required");
		return false;
	}if(lname == "" || lname == null){
		alert("Lname is required");
		return false;
	}if(mob=="" || mob==null){
		alert("Mob is required");
		return false;
	}
	return true;
    }
});

 app.controller("myCtrl",function($scope,$rootScope,myService){		
	
	$scope.fname = "";
	$scope.lname = "";
	$scope.mob = "";
	$scope.btn = "Submit";
        $scope.index = -1;
		
    $scope.onSubmit = function(){
	$scope.person={
		fname:$scope.fname,
		lname:$scope.lname,
		mob:$scope.mob
		};
	if(myService.validate($scope.fname,$scope.lname,$scope.mob)){
		if($scope.index == -1){
		  $rootScope.personsArray.push($scope.person);
		}else{
			$rootScope.personsArray.splice($scope.index,1,$scope.person);
			$scope.emptyFields();
		}
		console.log($rootScope.personsArray);
	}
    };

    $scope.onEdit = function(index){
	$scope.index = index;
	$scope.fname =  $rootScope.personsArray[index].fname;
	$scope.lname =  $rootScope.personsArray[index].lname;
	$scope.mob =  $rootScope.personsArray[index].mob;
	$scope.btn = "Update";
    };

    $scope.onDelete = function(index){
	$rootScope.personsArray.splice($scope.index,1);
    }

    $scope.emptyFields = function(){	
	$scope.fname = "";
	$scope.lname = "";
	$scope.mob = "";
	$scope.btn = "Submit";
        $scope.index = -1;
   }

 });
