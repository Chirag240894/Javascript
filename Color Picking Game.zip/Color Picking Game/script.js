
var numberOfSquares = 6;
var colors = generateRandomColors(numberOfSquares);
var rgb = document.getElementById('rgbCode');
var msgDiv = document.getElementById('message');
var square = document.querySelectorAll(".square");
var resetbtn = document.querySelector("#reset");
var esybtn = document.querySelector("#esybtn");
var hardbtn = document.querySelector("#hardbtn");
var h1 = document.querySelector('h1');
var pickedColor = pickColor();


resetbtn.addEventListener("click",function(){
    h1.style.background = "#556B2F";

    colors = generateRandomColors(numberOfSquares);
    pickedColor = pickColor();
    rgb.textContent = pickedColor;
    message.textContent = "";
    for(var i=0; i<square.length; i++){
        square[i].style.background = colors[i];
    }
});

esybtn.addEventListener("click",function(){
   msgDiv.textContent = "";
    h1.style.background = "#556B2F";
    hardbtn.classList.remove("selected");
    esybtn.classList.add("selected");
    numSquares = 3;
    colors = generateRandomColors(numSquares);
    pickedColor = pickColor();
    rgb.textContent = pickedColor;

    for(var i=0; i<square.length; i++){
        if(colors[i]){
            square[i].style.background = colors[i];
        }else{
            square[i].style.display = "none";
        }
    }
});

hardbtn.addEventListener("click", function(){
  msgDiv.textContent = "";
  h1.style.background = "#556B2F";
  esybtn.classList.remove("selected");
  hardbtn.classList.add("selected");
  numSquares = 6;
  colors = generateRandomColors(numSquares);
  pickedColor = pickColor();
  rgb.textContent = pickedColor;
  for(var i = 0; i < square.length; i++) {
      square[i].style.background = colors[i];
      square[i].style.display = "inline";
  }
});

rgb.innerHTML = pickedColor;
msgDiv.textContent = "";
for(var i=0; i<square.length; i++){
    square[i].style.background = colors[i];
    square[i].addEventListener("click",function(){
        var clickedColor = this.style.background;
        if(clickedColor == pickedColor){
            msgDiv.textContent = "Great Job!!!";
            changeColor(clickedColor);
            h1.style.background = clickedColor;
        }else{
            this.style.background = "#232323";
            msgDiv.textContent = "Try Again!!!";
        }
    })
}

function changeColor(color){
  for(var i=0; i<square.length; i++){
      square[i].style.background = color;
  }
}

function pickColor(){
    var randomColor = Math.floor(Math.random() * colors.length);
    return colors[randomColor];
}

function generateRandomColors(num){
      var arr = [];
      for(var i=0; i<num; i++){
          arr.push(randomColor());
      }
      return arr;
}

function randomColor(){
   var r = Math.floor(Math.random() * 256)
   var g = Math.floor(Math.random() * 256)
   var b = Math.floor(Math.random() * 256)
 return "rgb(" + r +", " + g + ", " + b +")";
}
